horastrabajo = int(input("Introduce las horas de trabajo : "))
print("Su importe total es de: ", horastrabajo*10, "€")