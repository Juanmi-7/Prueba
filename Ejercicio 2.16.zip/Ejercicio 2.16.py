lista = []
y = int(input("Introduzca un número entero positivo: "))
z = int(input("Introduzca otro número entero positivo: "))
x = 0
e = 0
for x in range(0, y):
    try:
        y/x
        if y/x == 0:
            lista.append(y)
        print(f"El resultado de la división es: {lista}")
        for e in range(0, z):
            try:
            z/e
            if z/e == 0:
                lista.append(z)
print("El resto de la división es: {}")