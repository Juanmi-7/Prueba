lista = []
input("Introduzca un número : ")
while True:
    try:
        n = 1
        lista = [n, -(n+1), n+2]
        lista.append
        print(f"{lista}")
        break
    except ValueError:
        print("Incorrecto.")