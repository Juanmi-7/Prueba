N1 = float(input("Introduce un primer número : "))
N1+= float(input("Introduce un segundo número : "))# N1 = N1 + nuevo numero por teclado
N1+= float(input("Introduce un tercer número : "))
print("El valor de la suma de los tres números es de : ", N1)