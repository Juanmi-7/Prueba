lista = []
num = 0
for num in range(0,51):
    if num %2 == 0:
        lista.append(num)
print(f"Los números pares son : {lista}")