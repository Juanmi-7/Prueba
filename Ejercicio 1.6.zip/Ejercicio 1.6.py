impfinal = float(input("Introduce el importe final de su artículo: "))
print("El importe de IVA pagado es de: ", impfinal-10/11*impfinal)
print("El importe del artículo sin IVA es de: ", 10/11*impfinal)