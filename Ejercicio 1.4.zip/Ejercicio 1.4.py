celsius = int(input("Introduce un valor en grados celsius: "))
print("El quivalente en grados fahrenheit es de: ", celsius*9/5+32)