nombre = input("Introduce tu nombre : ")
print("Hola ", nombre)