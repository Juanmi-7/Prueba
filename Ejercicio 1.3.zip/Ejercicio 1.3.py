ancho = 17
alto = 12.0
R1 = ancho/2
R2 = ancho//2
R3 = alto/3
R4 = 1+2*5
print("El resultado es: ", R1,R2,R3,R4)