N1 = float(input("Introduce un primer número : "))
N2 = float(input("Introduce un segundo número : "))
N3 = float(input("Introduce un tercer número : "))
print("La suma total es de : ", N1+N2+N3)