iva = float(input("Introduce el importe de su artículo: "))
print("El precio total del artículo con IVA es de: ", iva*21/100+iva)